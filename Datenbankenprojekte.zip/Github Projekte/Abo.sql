create Database if not exists Abo;

use Abo;

drop table if exists Ort;
drop table if exists Anrede;
drop table if exists Aboart;
drop table if exists Mitglied;


create table Ort
(	
OrtID			int							not null,
PLZ				int							null,
Ort				varchar(50)					null,
primary key (OrtID)
);

create table Anrede
(
AnredeID		int							not null,
Anrede 			enum('Herr', 'Frau')		null,
primary key (AnredeID)
);

create table Aboart
(
AboartID		int							not null,
Aboart			varchar(50)					null,
Gebuehr			decimal(6,2)				null,
primary key (AboartID)
);

create table Mitglied
(
MitgliedID		int							not null		auto_increment,
Abo				int							null,
Nachname		varchar(50)					null,
Vorname			varchar(50)					null,
Eintritt		date						null,
AboartID		int,
AnredeID		int,
OrtID			int,
primary key (MitgliedID),
foreign key (AboartID) references Aboart(AboartID),
foreign key (AnredeID) references Anrede(AnredeID),
foreign key (OrtID) references Ort(OrtID)
);


select Abo, Anrede, Nachname, Vorname, PLZ, Ort, Eintritt, Aboart, Gebuehr
from	Mitglied 
	inner join Aboart
    on Mitglied.AboartID = Aboart.AboartID
    inner join Anrede
    on Mitglied.AnredeID = Anrede.AnredeID
	inner join Ort
    on Mitglied.OrtID = Ort.OrtID;
    
    select nachname, vorname, eintritt
		from Mitglied
        order by eintritt asc;
        
select count(Nachname)
from Mitglied;

select nachname, vorname, eintritt
	from Mitglied
    where nachname like 'B%'
    order by nachname desc, vorname desc;
    