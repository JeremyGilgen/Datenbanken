-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 24. Apr 2016 um 17:11
-- Server-Version: 5.6.25
-- PHP-Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

CREATE DATABASE schweiz;
USE schweiz;

--
-- Datenbank: `schweiz`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kantone`
--

CREATE TABLE IF NOT EXISTS `kantone` (
  `kanton_id` int(11) unsigned NOT NULL,
  `bezeichnung` varchar(55) NOT NULL,
  `flaeche` int(11) NOT NULL,
  `bevoelkerung` int(11) NOT NULL,
  `bevoelkerungsdichte` int(11) NOT NULL,
  `hauptsprache` char(1) NOT NULL,
  `hauptort` varchar(55) NOT NULL,
  `einwohner` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `kantone`
--

INSERT INTO `kantone` (`kanton_id`, `bezeichnung`, `flaeche`, `bevoelkerung`, `bevoelkerungsdichte`, `hauptsprache`, `hauptort`, `einwohner`) VALUES
(1, 'Aargau, AG', 1404, 613000, 396, 'D', 'Aarau', 2000),
(2, 'Appenzell Ausserrhoden, AR', 243, 53000, 218, 'D', 'Herisau', 15000),
(3, 'Basel-Land, BL', 518, 276000, 508, 'D', 'Liestal', 13000),
(4, 'Bern, BE', 5959, 980000, 159, 'D', 'Bern', 124000),
(5, 'Appenzell Innerrhoden, IR', 173, 16000, 87, 'D', 'Appenzell', 6000),
(6, 'Basel-Stadt, BS', 37, 191000, 5027, 'D', 'Basel', 169000),
(7, 'Freiburg, FR', 1671, 278000, 145, 'F', 'Fribourg', 35000),
(8, 'Genf, GE', 282, 466000, 1486, 'F', 'Genf', 191000),
(9, 'Glarus, GL', 685, 39000, 56, 'D', 'Glarus', 12000),
(10, 'Graubuenden, GR', 7105, 193000, 27, 'R', 'Chur', 34000),
(11, 'Jura, JU', 839, 70000, 84, 'F', 'Delemont', 12000),
(12, 'Neuchatel, NE', 803, 172000, 214, 'F', 'Neuchatel', 33000),
(13, 'Luzern, LU', 1494, 378000, 253, 'D', 'Luzern', 77000),
(14, 'Nidwalden, NW', 276, 41000, 147, 'D', 'Stans', 8000),
(15, 'Obwalden, OW', 491, 36000, 72, 'D', 'Sarnen', 10000),
(16, 'St. Gallen, SG', 2026, 479000, 232, 'D', 'St. Gallen', 73000),
(17, 'Schaffhausen, SH', 299, 76000, 254, 'D', 'Schaffhausen', 35000),
(18, 'Schwyz, SZ', 908, 147000, 159, 'D', 'Schwyz', 14000),
(19, 'Solothurn, SO', 791, 257000, 325, 'D', 'Solothurn', 16000),
(20, 'Thurgau, TG', 991, 247000, 249, 'D', 'Frauenfeld', 23000),
(21, 'Tessin, TI', 2813, 334000, 119, 'I', 'Bellinzona', 17000),
(22, 'Uri, UR', 1077, 35000, 33, 'D', 'Altdorf', 9000),
(23, 'Waadt, VD', 3212, 718000, 224, 'F', 'Lausanne', 128000),
(24, 'Valais, VS', 5225, 313000, 59, 'F', 'Sion', 30000),
(25, 'Zug, ZG', 239, 112000, 468, 'D', 'Zug', 26000),
(26, 'Zürich, ZH', 1729, 1390000, 804, 'D', 'Zürich', 389000);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `kantone`
--
ALTER TABLE `kantone`
  ADD PRIMARY KEY (`kanton_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `kantone`
--
ALTER TABLE `kantone`
  MODIFY `kanton_id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
