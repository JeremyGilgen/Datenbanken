-- VideoDBInsert.sql.sql
--
-- Autor			: Jeremy Gilgen	
-- Erstellt			: 21.09.2018
-- Projekt			: Modul 159
-- Version			: 1.0
-- Ausführen als	: root
--
-- Change Log 	(Beispiel)
-- 07.03.2018	Jeremy erstellt
use Sender;


create table if not exists Land
(
	LandID		INT				Not Null 		auto_increment		primary key,
    Laendercode	varchar(50),
    Bezeichnung	varchar(50)
    
);

create table if not exists Kategorie
(
	KategorieID	INT				Not Null 		auto_increment		primary key,
    Kategorie	varchar(50)
    
);

create table if not exists Adresse
(
	AdresseID	INT				Not Null 		auto_increment		primary key,
    Titel		varchar(50),
    Bemerkung	varchar(50),
    Dauer		INT,
    Typ			Enum('sw','farbe')
    
);

create table if not exists Moderator
(
	ModeratorID	INT				Not Null 		auto_increment		primary key,
    Nachname	varchar(50),
    Vorname		varchar(50),
    Strasse		INT,
    AdresseID	INT,
	FOREIGN KEY(AdresseID)				
	REFERENCES Adresse (AdresseID)
);

create table if not exists Redaktor
(
	ModeratorID	INT				Not Null 		auto_increment		primary key,
    Nachname	varchar(50),
    Vorname		varchar(50),
    Honorar		DECIMAL(5,2),
    Strasse		INT,
    Adresse		INT,
    FOREIGN KEY(AdresseID)				
	REFERENCES Sender.Adresse(AdresseID)
    
);

create table if not exists Journalist
(
	ModeratorID	INT				Not Null 		auto_increment		primary key,
    Nachname	varchar(50),
    Vorname		varchar(50),
    Honorar		DECIMAL(5,2),
    Strasse		INT,
    AdresseID		INT,
    FOREIGN KEY(AdresseID)				
	REFERENCES Sender.Adresse(AdresseID)
    
);


create table if not exists Sendung
(
	SendungID	INT				Not Null 		auto_increment		primary key,
    Titel		varchar(50)		Not Null,
    Bemerkung	varchar(50),
    Dauer		INT				Not Null,
    Typ			Enum('sw','farbe'),
    FOREIGN KEY(RedaktorID)				
	REFERENCES Sender.Redaktor(RedaktorID),
    FOREIGN KEY(LandID)				
	REFERENCES Sender.Land(LandID),
    FOREIGN KEY(ModeratorID)				
	REFERENCES Sender.Moderator(ModeratorID),
    FOREIGN KEY(KategorieID)				
	REFERENCES Sender.Kategorie(KategorieID)
);

create table if not exists Beitrag
(
	BeitragID	INT				Not Null 		auto_increment		primary key,
    Textfile	varchar(50),
    FOREIGN KEY(JournalistID)				
	REFERENCES Sender.Journalist(JournalistID)
    
);

create table if not exists Sendungsinhalt
(
	SendungsinhaltID	INT				Not Null 		auto_increment		primary key,
    FOREIGN KEY(SendungID)				
	REFERENCES Sender.Sendung(SendungID),
    FOREIGN KEY(BeitragID)				
	REFERENCES Sender.Beitrag(BeitragID)
   
);