-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema SuperseriösAG
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema SuperseriösAG
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `SuperseriösAG` DEFAULT CHARACTER SET utf8 ;
USE `SuperseriösAG` ;

-- -----------------------------------------------------
-- Table `SuperseriösAG`.`Konten`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperseriösAG`.`Konten` (
  `KontenID` INT NOT NULL,
  `Kontobezeichnung` VARCHAR(50) NULL,
  `Limite` INT NULL,
  `Dispo` INT NULL,
  `Saldo` INT NULL,
  PRIMARY KEY (`KontenID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `SuperseriösAG`.`Kontobewegungen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperseriösAG`.`Kontobewegungen` (
  `KontobewegungenID` INT NOT NULL,
  `Datum` DATETIME NULL,
  `Buchungsbetrag` INT NULL,
  `Begünstigter bei Belastungen` VARCHAR(50) NULL,
  `Auftraggeber bei Vergütungen` VARCHAR(50) NULL,
  `KontenID` INT NOT NULL,
  PRIMARY KEY (`KontobewegungenID`),
  INDEX `fk_Kontobewegungen_Konten1_idx` (`KontenID` ASC),
  CONSTRAINT `fk_Kontobewegungen_Konten1`
    FOREIGN KEY (`KontenID`)
    REFERENCES `SuperseriösAG`.`Konten` (`KontenID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `SuperseriösAG`.`Kunden`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperseriösAG`.`Kunden` (
  `KundenID` INT NOT NULL,
  `Vorname` VARCHAR(50) NULL,
  `Nachname` VARCHAR(50) NULL,
  `Strasse` VARCHAR(50) NULL,
  `Postleitzahl` INT NULL,
  `Ort` VARCHAR(50) NULL,
  PRIMARY KEY (`KundenID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `SuperseriösAG`.`Konten_has_Kunden`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperseriösAG`.`Konten_has_Kunden` (
  `KontenID` INT NOT NULL,
  `KundenID` INT NOT NULL,
  PRIMARY KEY (`KontenID`, `KundenID`),
  INDEX `fk_Konten_has_Kunden_Kunden1_idx` (`KundenID` ASC),
  INDEX `fk_Konten_has_Kunden_Konten_idx` (`KontenID` ASC),
  CONSTRAINT `fk_Konten_has_Kunden_Konten`
    FOREIGN KEY (`KontenID`)
    REFERENCES `SuperseriösAG`.`Konten` (`KontenID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Konten_has_Kunden_Kunden1`
    FOREIGN KEY (`KundenID`)
    REFERENCES `SuperseriösAG`.`Kunden` (`KundenID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

insert into Konten (vorname, nachname)
value ("Mark", "Fuchs");



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
