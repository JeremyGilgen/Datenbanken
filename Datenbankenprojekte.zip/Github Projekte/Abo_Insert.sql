use Abo;

insert into Ort (OrtID, PLZ, Ort)
	values(1, 8000, 'Zürich'),
		(2, 8021, 'Zürich'),
		(3, 8048, 'Zürich'),
		(4, 3000, 'Bern'),
        (5, 4000, 'Basel');
        
	
insert into Anrede (AnredeID, Anrede)
	values(1, 'Herr'),
			(2, 'Frau');
    
insert into Aboart (AboartID, Aboart, Gebuehr)
	values(1, 'Student', 500.00),
			(2, 'Jahresabo', 1000.00),
			(3, 'Monatsabo', 150.00);

insert into Mitglied (Abo, Nachname, Vorname, Eintritt, AboartID, AnredeID, OrtID)
	values(33,'Balmelli', 'Marco', '1990-01-01', 1, 2, 1),
			(44, 'Bürgin', 'Sandra', '1989-05-01', 2, 1, 2),
            (55, 'Emmenegger', 'Reto', '1994-10-01', 3, 2, 3),
            (66, 'Keller', 'George', '1996-11-30', 2, 1, 2),
            (77, 'Müller', 'Karina', '2005-08-30', 2, 1, 4),
            (88, 'Groz', 'Thomas', '2005-07-15', 1, 1, 5),
            (99, 'Isabelle', 'Pozzi', '2005-07-15', 3, 2, 4);
    