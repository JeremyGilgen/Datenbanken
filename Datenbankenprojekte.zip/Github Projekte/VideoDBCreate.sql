-- Create_Table.sql
--
-- Autor			: Jeremy Gilgen	
-- Erstellt			: 04.01.2017
-- Projekt			: Modul 104
-- Version			: 1.0
-- Ausführen als	: root
--
-- Change Log (Beispiel)
-- 04.01.2017	Ich erstelle Datenbank
-- 07.03.2017 Ich Darsteller Tabelle hinzugefügt




-- Datenbank wählen
use sakila;

-- Alle Datensätze anzeigen
select * from film;

-- Datenbank erstellen
create database if not exists videoverwaltung; -- Mach Datenbank nur dann neu, wenn sie noch nicht existiert.

-- Daten anwählen
use videoverwaltung;

-- Tabelle erstellen
create table kunde_Beispiel
(
	Kundennummer	int			not null		auto_increment,
    primary key (Kundennummer)
);

-- löscht die Tabelle
drop table kunde;
drop table film;
drop table ausleihe;

-- löscht nur dann, wenn die Tabelle auch existiert
-- Die Tabellen mit Fremdschlüssel zuerst löschen, da diese Beziehungen sonst noch bestehen würden.
drop table if exists ausleihe;
drop table if exists film_darsteller;
drop table if exists film_regisseur;
drop table if exists kunde;
drop table if exists film;
drop table if exists darsteller;
drop table if exists regisseur;

-- Tabelle Kunde erstellen
create table Kunde 
(
	Kundennummer	int						not null	auto_increment, -- autmoatische Fortsetzung, not null = Pflichtfeld
    Anrede			enum('Herr', 'Frau'),								-- Man kann nur die Inhalte der Klammer verwenden
    Vorname			varchar(20)				null,						-- null = optional
    Nachname		varchar(20)				null, 
    Strasse			varchar(25)				null, 
    PLZ				INT						null,
    Ort				varchar(20)				null,
    Geburtsdatum	date					null,
    Primary Key		(Kundennummer) -- Um Primärschlüssel zu definieren. Geht auch, wenn man primary key hinter einem Attribut hinschreibt.
);	


create table Film
(
	Videonummer 	int 					not null 	auto_increment,
	Titel 			varchar(40),				
    Dauer			int						default 120, -- default = standard wert
    Kategorie		varchar(20),				
    Jahr			int,				
    Frei_ab			int,						
    PreisProTag		numeric(6,2),			
    EPreis			numeric(6,2),			
    Lagerbestand	int						default 0,
    primary key (Videonummer)
);


-- Diese Tabelle muss als letztes stehen, da diese sonst nicht die anderen Tabelle referrenzieren, da diese noch gar nicht eingelesen sind/existieren.
create table Ausleihe
(
	Ausleihnr		int						not null	auto_increment,
    Kundennummer	int						not null,
    Videonummer		int						not null,
    Ausleihe		date,	
    Rueckgabe		date,
    -- Suchfunktion. In der Datenbank wird ein Kundensatz nun bei der Tabelle Kundennummer gesucht
    index (Kundennummer), 
    index (Videonummer),
    primary key (Ausleihnr),
    -- Fremdschlüssel hinzufügen
    foreign key (Kundennummer) references Kunde(Kundennummer), -- foreign key, um das Beziehungsattribut in Klammern einzufügen, references, um die Tabelle auszuwählen, welche den primären Schlüssel davon in sich trägt 
    foreign key (Videonummer) references Film(Videonummer)		-- Bei Film(Videonummer) könnte in der Klammer auch (VNr) stehen, je nach dem was in der Originaltabelle der primäre Schlüssel ist.
);

create table Darsteller
(	
	DNr				int						not null	auto_increment,
    VornameD		varchar(20)				null,
    NachnameD		varchar(20)				null,
    primary key (DNr)
);

create table Regisseur
(
	RNr				int						not null	auto_increment,
    VornameR		varchar(20)				null,
    NachnameR		varchar(20)				null,
    primary key (RNr)
);

create table Film_Regisseur
(
	FNr				int						not null,
    RNr				int						not null,
	primary key (FNr, RNr), -- Der Primärschlüssel kann auch aus 2 Attributen bestehen
	foreign key (FNr) references Film(Videonummer),
    foreign key (RNr) references Regisseur(RNr)
);
	

create table Film_Darsteller
(
	FNr				int						not null,
    DNr				int						not null,
	primary key (FNr, DNr),
	foreign key (FNr) references Film(Videonummer),
    foreign key (DNr) references Darsteller(DNr)
);