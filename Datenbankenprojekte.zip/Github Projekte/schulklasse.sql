-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 24. Apr 2016 um 17:21
-- Server-Version: 5.6.25
-- PHP-Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `schulklasse`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `klassen`
--

CREATE TABLE IF NOT EXISTS `klassen` (
  `klasse_id` int(11) NOT NULL,
  `bezeichnung` varchar(222) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `klassen`
--

INSERT INTO `klassen` (`klasse_id`, `bezeichnung`) VALUES
(1, 'Apl15'),
(2, 'PSY12');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lehrer`
--

CREATE TABLE IF NOT EXISTS `lehrer` (
  `lehrer_id` int(11) NOT NULL,
  `nachname` varchar(222) NOT NULL,
  `vorname` varchar(222) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `lehrer`
--

INSERT INTO `lehrer` (`lehrer_id`, `nachname`, `vorname`) VALUES
(8, 'Herpel', 'Alfons'),
(9, 'Greiwe', 'Andrea'),
(10, 'Scholl', 'Nadja'),
(11, 'Rusch', 'Daniel'),
(12, 'Greiwe', 'Anrea');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lehrer2modul`
--

CREATE TABLE IF NOT EXISTS `lehrer2modul` (
  `l2m_id` int(11) unsigned NOT NULL,
  `lehrer_id` int(11) NOT NULL,
  `modul_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `lehrer2modul`
--

INSERT INTO `lehrer2modul` (`l2m_id`, `lehrer_id`, `modul_id`) VALUES
(1, 9, 146),
(2, 9, 300),
(3, 11, 126),
(4, 8, 100),
(5, 10, 105);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `modul_id` int(11) NOT NULL,
  `bezeichnung` varchar(222) NOT NULL,
  `schwerpunkt` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `module`
--

INSERT INTO `module` (`modul_id`, `bezeichnung`, `schwerpunkt`) VALUES
(100, 'Daten charakterisieren', 'Allgemein'),
(105, 'Datenbanken mit SQL bearbeiten', 'Allgemein'),
(126, 'Peripheriegeräte im Netzwerkbetrieb einsetzen', 'Systemtechnik'),
(146, 'Internetanbindung für ein Unternehmen realisieren', 'Applikationsentwicklung'),
(300, 'Plattformübergreifende Dienste in ein Netzwerk integrieren', 'Systemtechnik');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schueler`
--

CREATE TABLE IF NOT EXISTS `schueler` (
  `schueler_id` int(11) NOT NULL,
  `klasse_id` int(11) NOT NULL,
  `schwerpunkt_id` int(11) NOT NULL DEFAULT '2',
  `geschlecht` char(1) NOT NULL,
  `nachname` varchar(25) NOT NULL,
  `vorname` varchar(25) NOT NULL,
  `sch_alter` int(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `schueler`
--

INSERT INTO `schueler` (`schueler_id`, `klasse_id`, `schwerpunkt_id`, `geschlecht`, `nachname`, `vorname`, `sch_alter`) VALUES
(1, 1, 1, 'm', 'Roth', 'Simon', 16),
(2, 2, 2, 'w', 'Prieth', 'Marianne', 20),
(3, 1, 3, 'm', 'Pond', 'Emil', 19),
(4, 1, 3, 'w', 'Schaub', 'Nicole', 20),
(5, 1, 3, 'w', 'Spirig', 'Conny', 19),
(6, 2, 2, 'm', 'Peter', 'Albert', 20),
(7, 1, 1, 'm', 'Abt', 'Andreas', 21),
(8, 1, 3, 'w', 'Samin', 'Dana', 22),
(9, 1, 3, 'm', 'Redowski', 'Theon', 21),
(10, 1, 3, 'w', 'Scholl', 'Nadja', 28);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schueler2modul`
--

CREATE TABLE IF NOT EXISTS `schueler2modul` (
  `s2m_id` int(11) unsigned NOT NULL,
  `schueler_id` int(11) NOT NULL,
  `modul_id` int(11) NOT NULL,
  `note` decimal(2,1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `schueler2modul`
--

INSERT INTO `schueler2modul` (`s2m_id`, `schueler_id`, `modul_id`, `note`) VALUES
(1, 1, 126, '3.5'),
(2, 7, 105, '6.0'),
(3, 2, 126, '5.5'),
(4, 5, 105, '1.0'),
(5, 4, 100, '4.0'),
(6, 1, 146, '4.5'),
(7, 1, 300, '5.0'),
(8, 4, 300, '4.0'),
(9, 2, 100, '5.0'),
(10, 6, 100, '4.5'),
(11, 3, 300, '6.0'),
(12, 8, 300, '4.5'),
(13, 1, 100, '3.5'),
(14, 1, 105, '4.0'),
(19, 2, 105, NULL),
(21, 2, 146, '2.0'),
(22, 2, 300, '4.0'),
(23, 3, 100, '2.5'),
(24, 3, 105, '5.5'),
(25, 3, 126, '4.0'),
(26, 3, 146, '1.0'),
(29, 4, 105, '6.0'),
(30, 4, 126, '4.5'),
(31, 4, 146, '3.5'),
(33, 5, 100, '1.0'),
(35, 5, 126, '5.0'),
(36, 5, 146, '1.5'),
(37, 5, 300, NULL),
(39, 6, 105, NULL),
(40, 6, 126, '4.0'),
(41, 6, 146, '5.0'),
(42, 6, 300, '2.0'),
(43, 7, 100, '1.0'),
(45, 7, 126, '6.0'),
(46, 7, 146, '5.5'),
(47, 7, 300, '3.0'),
(48, 8, 100, '4.5'),
(49, 8, 105, '4.5'),
(50, 8, 126, '5.5'),
(51, 8, 146, '6.0'),
(53, 9, 100, '3.5'),
(54, 9, 105, '6.0'),
(55, 9, 126, '4.5'),
(56, 9, 146, '5.0'),
(57, 9, 300, '4.0');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schwerpunkte`
--

CREATE TABLE IF NOT EXISTS `schwerpunkte` (
  `schwerpunkt_id` int(11) NOT NULL,
  `bezeichnung` varchar(222) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `schwerpunkte`
--

INSERT INTO `schwerpunkte` (`schwerpunkt_id`, `bezeichnung`) VALUES
(1, 'Systemtechnik'),
(2, 'Allgemein'),
(3, 'Applikationsentwicklung');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `klassen`
--
ALTER TABLE `klassen`
  ADD PRIMARY KEY (`klasse_id`);

--
-- Indizes für die Tabelle `lehrer`
--
ALTER TABLE `lehrer`
  ADD PRIMARY KEY (`lehrer_id`);

--
-- Indizes für die Tabelle `lehrer2modul`
--
ALTER TABLE `lehrer2modul`
  ADD PRIMARY KEY (`l2m_id`);

--
-- Indizes für die Tabelle `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`modul_id`);

--
-- Indizes für die Tabelle `schueler`
--
ALTER TABLE `schueler`
  ADD PRIMARY KEY (`schueler_id`);

--
-- Indizes für die Tabelle `schueler2modul`
--
ALTER TABLE `schueler2modul`
  ADD PRIMARY KEY (`s2m_id`);

--
-- Indizes für die Tabelle `schwerpunkte`
--
ALTER TABLE `schwerpunkte`
  ADD PRIMARY KEY (`schwerpunkt_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `klassen`
--
ALTER TABLE `klassen`
  MODIFY `klasse_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `lehrer`
--
ALTER TABLE `lehrer`
  MODIFY `lehrer_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT für Tabelle `lehrer2modul`
--
ALTER TABLE `lehrer2modul`
  MODIFY `l2m_id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT für Tabelle `schueler`
--
ALTER TABLE `schueler`
  MODIFY `schueler_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT für Tabelle `schueler2modul`
--
ALTER TABLE `schueler2modul`
  MODIFY `s2m_id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT für Tabelle `schwerpunkte`
--
ALTER TABLE `schwerpunkte`
  MODIFY `schwerpunkt_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
