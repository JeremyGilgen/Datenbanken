use tontraeger;
-- aufruf der SPgetAlbum
call getAlbum();

call insertalbum('Heino', 'CD', 5.5);

select * from album;