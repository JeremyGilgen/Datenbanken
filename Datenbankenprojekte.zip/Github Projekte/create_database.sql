-- VideoDBInsert.sql.sql
--
-- Autor			: Jeremy Gilgen	
-- Erstellt			: 21.09.2018
-- Projekt			: Modul 159
-- Version			: 1.0
-- Ausführen als	: root
--
-- Change Log 	(Beispiel)
-- 07.03.2018	Jeremy erstellt
Create database if not exists Sender;
use Sender;