
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`artikel2bestellung`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`artikel2bestellung` (
  `a2b_id` INT NOT NULL AUTO_INCREMENT,
  `bestellung_id` INT NULL,
  `artikel_id` INT NULL,
  `anzahl` INT NULL,
  `preis` DECIMAL(5,2) NULL,
  PRIMARY KEY (`a2b_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`bestellungen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`bestellungen` (
  `bestellung_id` INT NOT NULL AUTO_INCREMENT,
  `kunde_id` INT NULL,
  `mitarbeiter_id` INT NULL,
  `status` INT(5) NULL,
  PRIMARY KEY (`bestellung_id`),
  CONSTRAINT `fk_bestellungen_artikel2bestellung1`
    FOREIGN KEY (`bestellung_id`)
    REFERENCES `mydb`.`artikel2bestellung` (`bestellung_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`kunden`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`kunden` (
  `kunde_id` INT NOT NULL AUTO_INCREMENT,
  `nachname` VARCHAR(45) NULL,
  `vorname` VARCHAR(45) NULL,
  `strasse` VARCHAR(45) NULL,
  `plz` INT NULL,
  `ort` VARCHAR(45) NULL,
  `geburtstag` DATE NULL,
  PRIMARY KEY (`kunde_id`),
  CONSTRAINT `fk_kunden_bestellungen1`
    FOREIGN KEY (`kunde_id`)
    REFERENCES `mydb`.`bestellungen` (`kunde_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`artikel`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`artikel` (
  `artikel_id` INT NOT NULL AUTO_INCREMENT,
  `bezeichnung` VARCHAR(45) NULL,
  `preis` DECIMAL(5,2) NULL,
  `lager` INT NULL,
  PRIMARY KEY (`artikel_id`),
  CONSTRAINT `fk_artikel_artikel2bestellung1`
    FOREIGN KEY (`artikel_id`)
    REFERENCES `mydb`.`artikel2bestellung` (`artikel_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`mitarbeiter`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`mitarbeiter` (
  `mitarbeiter_id` INT NOT NULL AUTO_INCREMENT,
  `nachname` VARCHAR(45) NULL,
  `vorname` VARCHAR(45) NULL,
  `akadgrad` VARCHAR(45) NULL,
  PRIMARY KEY (`mitarbeiter_id`),
  CONSTRAINT `fk_mitarbeiter_bestellungen1`
    FOREIGN KEY (`mitarbeiter_id`)
    REFERENCES `mydb`.`bestellungen` (`mitarbeiter_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
