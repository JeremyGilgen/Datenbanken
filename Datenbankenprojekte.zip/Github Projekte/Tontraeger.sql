-- Tonträger Uebung --
--
-- autor 
-- projekt modul 153 tonträger -- 


create database tontraeger; 

use tontraeger;


drop table if exists Albuminhalt;
drop table if exists AlbumInterpret;
drop table if exists Album;
drop table if exists Musikstueck;
drop table if exists Stil;
drop table if exists Ort;
drop table if exists Interpret;

create table Interpret  
(
	InterpretId int Not Null auto_increment primary key , 
    InterpretName varchar(45)
);

create table Ort 
(
	OrtId int Not null auto_increment primary key,
    Bezeichnung varchar(45)
);

create table Stil
(
	StilId int Not null auto_increment primary key,
    Bezeichnung varchar(45)
);

create table Musikstueck
(
	MusikstueckId int Not Null auto_increment primary key,
    Titel varchar(45) not null,
    Dauer decimal(7,2),
    Bewertung decimal(7,2),
    StilId int,
    foreign key (StilID) references Stil(StilID)
) ;

create table Album
(
	AlbumId int Not null auto_increment primary key,
    Titel varchar(45) not null,
    Träger varchar(45),
    Noten decimal(7,2),
    OrtId int,
    foreign key (OrtId) references Ort(OrtId)
);

create table AlbumInterpret
( 
	AlbumId int,
    InterpretId int,
    foreign key (AlbumId) references Album(AlbumId),
    foreign key (InterpretId) references Interpret(InterpretId),
    primary key (AlbumId, InterpretId)
    
);

create table Albuminhalt
(
	AlbumId int,
    MusikstueckId int,
    foreign key(AlbumId) references Album(AlbumId),
    foreign key(MusikstueckId) references Musikstueck(MusikstueckId),
    primary key (AlbumId,MusikstueckID)
);


Insert into Interpret(Interpretname)
	values 	("Stephan Eicher"),
			("Roxette"),
            ("Die Prinzen"),
            ("Ace of Base"),
            ("Nimm zwei");


Insert into Ort (Bezeichnung)
	values	("cd-ständer"),
			("kasten");

Insert into Stil(Bezeichnung)
	values	("Pop"),
			("Accapella"),
			("Kabarett rock");
            
Insert into Musikstueck(Titel,Dauer,Bewertung)
	values 	("i tell this night",04.52, 5),
			("two people in a room", 04.08, 5.5),
            ("tu tournes mon coeur",04.43, 4.5),
            ("Joyride", 04.30, 5.5),
            ("Gabi und Klaus", 03.23,5.5),
            ("Happy Nation", 04.00, 5.5),
            ("Mein Fahrrad",02.25, 5.5),
            ("die Vögel", 04.52, 3.5),
            ("mr pharao", 05.46,6),
            ("slimer", 03.48,6),
            ("wie ein sturm",05.35, 5);

Insert into Album(Titel,Träger,Noten,OrtId)
	values 	("i tell this night","cd", 5, 1),
			("pop95", "mc" ,5.5,  2),
            ("das leben ist grausam", "cd", 5, 1),
            ("wir wollen nur deine seele","cd", 5.5, 1);
            

Insert into AlbumInterpret(InterpretId,AlbumId)
	values	(1,1),
			(2,2),
            (3,2),
            (4,2),
			(3,3),
            (5,4);
		
        
Insert into AlbumInhalt(AlbumId, MusikstueckId)
	values 	(1,1),
			(1,2),
            (1,3),
            (2,4),
            (2,5),
            (2,6),
            (3,5),
            (3,7),
            (3,8),
            (4,9),
            (4,10),
            (4,11);
            

            

