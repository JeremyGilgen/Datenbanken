-- Schulverwaltung_Hausaufgabe.sql
--
-- Autor			: Jeremy Gilgen	
-- Erstellt			: 07.03.2018
-- Projekt			: Modul 104
-- Version			: 1.0
-- Ausführen als	: root
--
-- Change Log (Beispiel)
-- 07.03.2018	Jeremy erstellt


create database if not exists Schulverwaltung_Hausaufgabe_neu;


use Schulverwaltung_Hausaufgabe_neu;

drop table if exists Student;
drop table if exists Studium;
drop table if exists Kurse;
drop table if exists Belegung;


create table Student
(
StudentNr			int			not null 		auto_increment,
Nachname			varchar(20)	null,						
Vorname				varchar(20) null,
Geburtsdatum		date 		not null,
Fachrichtung		varchar(30),
primary key (StudentNr),
foreign key (Fachrichtung)	references Studium(Fachrichtung) 
);

create table Studium
(
Fachrichtung		varchar(20)			not null,
AnzahlSemester		int					null,
primary key (Fachrichtung)	
);

create table Kurse
(
KursNr				int			not null		auto_increment,
Bezeichnung			varchar(20)					null,
primary key (KursNr)
);

create table Belegung
(
StudentNr			int			not null auto_increment,
KursNr				int			not null,
primary key (StudentNr, KursNr),
foreign key (StudentNr) references Student(StudentNr),
foreign key	(KursNr)	references Kurse(KursNr)
);

select * from kurse;

select * from belegung;

 -- kann nicht gelöscht werden, da noch Beziehungen bestehen.   
delete from kurse
	where kursnr = 1;
    
select * from belegung;

-- löschen
delete from belegung
	where StudentNr=1 and KursNr=1;
    
    select * from student;
    
    update student
    set name='Mayer'
	where Name='Baver'
    and Vorname='Ina';