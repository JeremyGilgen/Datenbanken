
-- Datenbank wählen
use sakila;

-- Alle Datensätze anzeigen
select * from film;

-- Datenbank erstellen
create database videoverwaltung;

-- Daten anwählen
use videoverwaltung;

-- Tabelle erstellen
create table film
(
	Videonummer int not null,
	Titel varchar(50)
);

-- Tabelle Kunde erstellen
create table Kunde 
(
	Kundennummer	int						not null	auto_increment, -- autmoatische Fortsetzung, not null = Pflichtfeld
    Anrede			enum('Herr', 'Frau'),								-- Man kann nur die Inhalte der Klammer verwenden
    Vorname			varchar(20)				null,						-- null = otional
    Nachname		varchar(20)				null, 
    Strasse			varchar(25)				null, 
    PLZ				INT						null,
    Ort				varchar(20)				null,
    Geburtsdatum	date					null,
    Primary Key		(Kundennummer) -- Um Primärschlüssel zu definieren. Geht auch, wenn man primary key hinter einem Attribut hinschreibt.
);	