-- Schulverwaltung_Hausaufgabe.sql
--
-- Autor			: Jeremy Gilgen	
-- Erstellt			: 07.03.2018
-- Projekt			: Modul 104
-- Version			: 1.0
-- Ausführen als	: root
--
-- Change Log (Beispiel)
-- 07.03.2018	Jeremy erstellt

use Schulverwaltung_hausaufgabe_neu;

insert into student (Nachname, Vorname, Geburtsdatum, Fachrichtung)
		values	('Müller', 'Hans', 1990-03-01,'BWL');
        
insert into student (Nachname, Vorname, Geburtsdatum, Fachrichtung)
		values	('Maier', 'Lieschen', 1991-02-21, 'Maschinenbau');
        
insert into student (Nachname, Vorname, Geburtsdatum, Fachrichtung)
		values	('Schulz', 'Klaus', 1998-03-11, 'BWL');
        
insert into student (Nachname, Vorname, Geburtsdatum, Fachrichtung)
		values	('Bayer', 'Ina', 1988-08-08, 'Maschinenbau');
        
insert into student (Nachname, Vorname, Geburtsdatum, Fachrichtung)
		values	('Schmidt', 'Egon', 1984-02-12, 'Biologe');


insert into Studium (Fachrichtung, Semester)
		values	('BWL', 6);
        
insert into Studium (Fachrichtung, Semester)
		values	('Maschinenbau', 7);
        
insert into Studium (Fachrichtung, Semester)
		values	('Biologie', 8);
        
        
insert into Kurse (KursNr, Bezeichnung)
		values	(1, 'VWL');
        
insert into Kurse (KursNr, Bezeichnung)
		values	(2, 'Mathe');

insert into Kurse (KursNr, Bezeichnung)
		values	(3, 'EDV');

insert into Kurse (KursNr, Bezeichnung)
		values	(4, 'Vererbungslehre');
        

insert into Belegung (StudentNr, KursNr)
		values	(1, 1);
        
insert into Belegung (StudentNr, KursNr)
		values	(1, 2);
        
insert into Belegung (StudentNr, KursNr)
		values	(1, 3);
        
insert into Belegung (StudentNr, KursNr)
		values	(2, 2);
        
insert into Belegung (StudentNr, KursNr)
		values	(3, 2);
        
insert into Belegung (StudentNr, KursNr)
		values	(3, 3);
        
insert into Belegung (StudentNr, KursNr)
		values	(4, 2);
        
insert into Belegung (StudentNr, KursNr)
		values	(5, 4);