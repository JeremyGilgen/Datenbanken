-- VideoDBInsert.sql.sql
--
-- Autor			: Jeremy Gilgen	
-- Erstellt			: 21.09.2018
-- Projekt			: Modul 159
-- Version			: 1.0
-- Ausführen als	: root
--
-- Change Log 	(Beispiel)
-- 07.03.2018	Jeremy erstellt
use sender;

create index idx_Sendung_Titel On Sender.Sendung(Titel asc);
create index idx_Sendung_Dauer On Sender.Sendung(Dauer asc);