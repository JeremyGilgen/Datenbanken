-- VideoDBInsert.sql.sql
--
-- Autor			: Jeremy Gilgen	
-- Erstellt			: 07.03.2018
-- Projekt			: Modul 104
-- Version			: 1.0
-- Ausführen als	: root
--
-- Change Log (Beispiel)
-- 07.03.2018	Jeremy erstellt

use Videoverwaltung;

-- Film einfügen
-- Bei Text muss man den Inhalt in Hochkomma schreiben, bei int nicht.
insert into film 	(Titel, 	Dauer, 	Kategorie, 	Jahr, 	Frei_ab, 	PreisProTag, 	EPreis, 	Lagerbestand)
			values(	'Papa Moll', 120, 	'KOM', 		2017, 	6, 			5.50, 			24.00, 		10);
insert into film (Titel, Dauer, Kategorie, Jahr, Frei_ab, PreisProTag, EPreis, Lagerbestand)
            values('King Kong', 120, 'ACT', 1998, 6, 8.50, 34.00, 18);

-- alle Film Datensätze anzeigen
select * from film
            