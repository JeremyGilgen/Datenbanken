use videoverwaltung_fertig;

-- alle Kunden anzeigen
select * from kunde;

-- einzelne Spalten anzeigen
select Vorname, Nachname from kunde;

-- einzelne Zeilen anzeigen
select * from kunde
	where Ort = 'Bassersdorf'; -- Zeilen Restriktion (where Klausel)
    
    -- einzelne Spalten und einzelne Zeilen
    select Vorname, Nachname from kunde
		where ort='Kloten';
        
select Titel, EPReis
	from film
    where EPReis > 30;
    
select Titel, Kategorie, EPreis
	from film
    where EPreis > 30 and Kategorie = 'KRI';
    
select Titel, Kategorie
	from film
    where EPreis > 30 or Kategorie = 'KRI';
    
select Titel, Kategorie, jahr
from film
	where Kategorie = 'KRI'
    or Kategorie = 'ACT'
    and Jahr = 1990;
    
select Vorname, Nachname
from kunde
	where Nachname LIKE 'Me%er';
    
select Vorname, Nachname
	from kunde
    where Nachname Like 'Me_er';
    
-- beliebig kombinierbar
select Vorname, Nachname
	from kunde
    where Nachname like 'M%__%er';

select Vorname, Nachname, Ort
	from kunde
    order by Nachname asc; -- für aufsteigend, asc muss man aber nicht schreiben, da es standard aufsteigend ist.
    
select Vorname, Nachname, Ort
	from kunde
    order by Nachname desc; -- absteigend
    
select Vorname, Nachname, Ort
	from kunde
    order by ort, Nachname; -- erste Priorität nach Ortschaft, 2. Priorität nach Nachname. 
    
select Vorname, Nachname, Ort
	from kunde
    order by ort, Nachname desc; -- Nachname ist jetzt absteigend, Ort nicht.
    
select Vorname, Nachname, Ort
	from kunde
    where ort = 'Kloten'
    order by Nachname; -- Order by steht immer am Schluss.
    
select Kategorie, count(*) 
	from film -- damit wird gezählt, wie viele Treffer er bei jeder Gruppe hat
	group by Kategorie 		-- Jede Kategorie kommt jetzt nur noch einmal.
    order by Kategorie;
    
select count(*) from film; -- So kann man das auch anders schreiben

select Kategorie, sum(lagerbestand) -- Durch sum wird von jeder einzelnen Kategorie die einzelnen Lagerbestände aufsummiert.
	from film
    group by Kategorie
	order by Kategorie;
    
select Kategorie, min(lagerbestand) -- Der kleinste Lagerbestand der Kategorie wird angezeigt
	from film
    group by Kategorie
	order by Kategorie;

select Kategorie, max(lagerbestand) -- Der grösste Lagerbestand der Kategorie wird angezeigt
	from film
    group by Kategorie
	order by Kategorie;
    
select sum(lagerbestand) -- Der komplette Lagerbestand von allen Filmen wird angezeigt
	from film;
    
select sum(lagerbestand), 
	min(lagerbestand),
	max(lagerbestand)
    from film;
    
select Kategorie, sum(lagerbestand),
	min(lagerbestand),
    max(lagerbestand)
	from film
    group by Kategorie
	order by Kategorie;
    


select * from kunde;  -- falsch, damit findet man nicht heraus, welcher Kunde welchen Film ausgeliehen hat.

select * from ausleihe; -- Da sieht man nur, welche Nummer welchen Film ausgeliehen hat.

select * from film; -- Diese 3 Tabellen einfach so dem Chef abgeben ist schlecht und unübersichtlich.

-- richtig
select * from film inner join ausleihe 
    on film.videonummer = ausleihe.Videonummer
    inner join kunde
    on ausleihe.kundennummer = Kunde.Kundennummer; -- obs links so oder umgekehrt geschrieben wird, spielt keine Rolle
    
select 	film.videonummer,		-- damit wählt man spezifische Zeilen
		film.titel,
		ausleihe.ausleihe,
        ausleihe.rueckgabe,
		kunde.kundennummer,
        kunde.vorname,
        kunde.nachname
	from film inner join ausleihe  
    on film.videonummer = ausleihe.Videonummer
    inner join kunde
    on ausleihe.kundennummer = Kunde.Kundennummer;
    
-- umgebaute version der Tabelle von oben. Wörter wurden mit (as **) vereinfacht.
select 	f.videonummer,		
		f.titel,
		d.vornameD,
		d.nachnameD
		
	from film as f 
    inner join film_darsteller as fd 
    on f.videonummer = fd.FNr
    inner join  darsteller as d
    on fd.DNr = d.DNr; 

-- Hier passt man jeden Spaltentitel an, indem man den gewollten Name hintendran schreibt
select 	film.videonummer FilmNummer,		
		film.titel Filmtitel,
		darsteller.vornameD DarstellerVorname,
		darsteller.nachnameD DarstellerNachname
		
	from film 
    inner join film_darsteller  
    on film.videonummer = film_darsteller.FNr
    inner join  darsteller
    on film_darsteller.DNr = darsteller.DNr; 
    
-- Version mit "as"
select 	film.videonummer as FilmNummer,		
		film.titel as Filmtitel,
		darsteller.vornameD as DarstellerVorname,
		darsteller.nachnameD as DarstellerNachname
		
	from film 
    inner join film_darsteller  
    on film.videonummer = film_darsteller.FNr
    inner join  darsteller
    on film_darsteller.DNr = darsteller.DNr; 
    
		-- Wie viel kosten Westernfilme im Durchschnitt
select avg(PreisProTag) as Durchschnittspreis
		from film
        where kategorie = 'WES';
        
        
        -- aufgabe Wie viele Frauen haben Filme aus der Kategorie "horror" ausgeliehen?
select count(*) as Anzahl from Kunde
        inner join ausleihe
        on kunde.kundennummer = ausleihe.Kundennummer
        inner join film
        on ausleihe.Videonummer = film.Videonummer
        where film.Kategorie = 'HOR'
        and kunde.Anrede = 'Frau';
        
   