-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema MitarbeiterDB
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema MitarbeiterDB
-- -----------------------------------------------------
drop schema MitarbeiterDB;
CREATE SCHEMA IF NOT EXISTS `MitarbeiterDB` DEFAULT CHARACTER SET utf8 ;
USE `MitarbeiterDB` ;



-- -----------------------------------------------------
-- Table `MitarbeiterDB`.`Mitarbeiter`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `MitarbeiterDB`.`Mitarbeiter` (
  `MitarbeiterID` INT NOT NULL	auto_increment,
  `Vorname` VARCHAR(50) NULL,
  `Nachname` VARCHAR(50) NULL,
  `Telefon` VARCHAR(50) NULL,
  `Jobtitel` VARCHAR(50) NULL,
  `Lohn` DECIMAL(5,2) NULL,
  `ChefID` INT NULL,
  PRIMARY KEY (`MitarbeiterID`),
  INDEX `fk_Mitarbeiter_Mitarbeiter1_idx` (`ChefID` ASC),
  CONSTRAINT `fk_Mitarbeiter_Mitarbeiter1`
    FOREIGN KEY (`ChefID`)
    REFERENCES `MitarbeiterDB`.`Mitarbeiter` (`MitarbeiterID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

Insert Into MitarbeiterDB.Mitarbeiter(MitarbeiterID, `Vorname`, `Nachname`, `Telefon`,`Jobtitel`, `Lohn`, ChefID) values	
(1,"Jeremy", "Gilgen", "0792489429", "Chef", 50.00, null),
(2,"Thomas", "Ensner", "0766146168", "Mitarbeiter", 20.00,1),
(3,"Leonit", "Perkusic", "0792489429", "Mitarbeiter", 30.00,1),
(4,"Daniel", "Stankic", "0792489429", "Mitarbeiter", 15.00,2),
(5,"Andreas", "Geiger", "0792489429", "Mitarbeiter", 12.00,2),
(6,"Tanya", "Guiller Näff", "0792489429", "Mitarbeiter", 14.00,3);
-- normalerweise anzeigen eines Inhalts mit referenzierung einer weiteren Tabelle
-- select * from Mitarbeiter			
-- 			inner join abteilung
--          on Mitarbeiter.abtID = abteilung.abtID;
 
-- Bei der Rekursion, muss man aliase einführen
 select * from Mitarbeiter as a
			inner join Mitarbeiter as b
            on a.MitarbeiterID = b.ChefID
            where a.Nachname = 'Gilgen';
-- Wenn ich wissen will, von wem ich der Chef bin
select b.* from Mitarbeiter as a
			inner join Mitarbeiter as b
            on a.MitarbeiterID = b.ChefID
            where a.Nachname = 'Gilgen';
-- Will wissen, wer mein Chef ist
select b.* from Mitarbeiter as a
			inner join Mitarbeiter as b
            on a.ChefID = b.MitarbeiterID
            where a.Nachname = 'Geiger';
            
            
-- -----------------------------------------------------
-- Table `MitarbeiterDB`.`Struktur`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `MitarbeiterDB`.`Struktur` (
  `StrukturID` INT NOT NULL,
  `MitarbeiterID` VARCHAR(50) NULL,
  `ManagerID` VARCHAR(50) NULL,
  PRIMARY KEY (`StrukturID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `MitarbeiterDB`.`Mitarbeiter`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `MitarbeiterDB`.`Mitarbeiter1` (
  `MitarbeiterID` INT NOT NULL,
  `vorname` VARCHAR(50) NULL,
  PRIMARY KEY (`MitarbeiterID`),
  CONSTRAINT `fk_Mitarbeiter_Struktur1`
    FOREIGN KEY (`MitarbeiterID`)
    REFERENCES `MitarbeiterDB`.`Struktur` (`MitarbeiterID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Mitarbeiter_Struktur2`
    FOREIGN KEY (`MitarbeiterID`)
    REFERENCES `MitarbeiterDB`.`Struktur` (`ManagerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

Insert Into MitarbeiterDB.Mitarbeiter1(MitarbeiterID, vorname) values	
(1,"Jeremy"),
(2,"Thomas"),
(3,"Leonit"),
(4,"Daniel"),
(5,"Andreas");

Insert Into MitarbeiterDB.Struktur(MitarbeiterID, ManagerID) values	
(3,1),
(4,1),
(4,2),
(5,2);


select m2.* from Mitarbeiter1 m1
			inner join Struktur fs on m1.MitarbeiterID = fs.ManagerID
            inner join Mitarbeiter1 m2 on fs.MitarbeiterID = m2.MitarbeiterID
            where m1.vorname = 'Jeremy';
            
SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
