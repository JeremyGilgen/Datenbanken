-- IsA_Beziehung
--
-- Autor			: Jeremy Gilgen	
-- Erstellt			: 21.09.2018
-- Projekt			: Modul 153
-- Version			: 1.0
-- Ausführen als	: root
--
-- Change Log 	(Beispiel)
-- 07.03.2018	Jeremy erstellt


-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema IsABeziehung
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema IsABeziehung
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `IsABeziehung`;
CREATE SCHEMA IF NOT EXISTS `IsABeziehung` DEFAULT CHARACTER SET utf8 ;
USE `IsABeziehung` ;

-- -----------------------------------------------------
-- Table `IsABeziehung`.`Person`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IsABeziehung`.`Person` (
  `Personal-Nr` INT NOT NULL,
  `Namen` VARCHAR(50) NULL,
  `Adresse` VARCHAR(50) NULL,
  `Geburtsdatum` DATETIME NULL,
  PRIMARY KEY (`Personal-Nr`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IsABeziehung`.`Kunde`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IsABeziehung`.`Kunde` (
  `KundeID` INT NOT NULL AUTO_INCREMENT,
  `Namen` VARCHAR(50) NULL,
  `Adresse` VARCHAR(50) NULL,
  `Geburtsdatum` DATETIME NULL,
  `Funktion` VARCHAR(50) NULL,
  `Umsatz` DECIMAL(5,2) NULL,
  PRIMARY KEY (`KundeID`),
  CONSTRAINT `fk_Kunde_Person1`
    FOREIGN KEY (`KundeID`)
    REFERENCES `IsABeziehung`.`Person` (`Personal-Nr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IsABeziehung`.`Dozent`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `IsABeziehung`.`Dozent` (
  `DozentID` INT NOT NULL AUTO_INCREMENT,
  `Namen` VARCHAR(50) NULL,
  `Adresse` VARCHAR(50) NULL,
  `Geburtsdatum` DATETIME NULL,
  `Biographie` VARCHAR(50) NULL,
  `Honorar_pro_Tag` DECIMAL(5,2) NULL,
  PRIMARY KEY (`DozentID`),
  CONSTRAINT `fk_Dozent_Person1`
    FOREIGN KEY (`DozentID`)
    REFERENCES `IsABeziehung`.`Person` (`Personal-Nr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

INSERT INTO Kunde(`KundeID`,`Namen`, `Adresse`, `Geburtsdatum`,`Funktion`, `Umsatz`) values	
(Null,"Peter Koch", "Bahnhofstrasse 12", "1974-03-15", "Kunde", 00512.50),
(Null, "Martin Baumer", "Flugzeugstrasse 911", "1980-12-14", "Kunde", 00560.50);

INSERT INTO Dozent(`DozentID`, `Namen`, `Adresse`, `Geburtsdatum`,`Biographie`, `Honorar_pro_Tag`) values	
(Null, "Peter Kocher", "Bahnhofstrasse 14", "1974-03-20", "blabla", 351.15),
(Null, "Martin Baumerli", "Helikopterweg 88", "1980-12-14", "Blabla", 500.15);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


