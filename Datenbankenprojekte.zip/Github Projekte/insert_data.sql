-- genericdb.sql
--
-- Autor			: Jeremy Gilgen	
-- Erstellt			: 26.09.2018
-- Projekt			: Modul 159
-- Version			: 1.0
-- Ausführen als	: root
--
-- Change Log 	(Beispiel)
-- 07.03.2018	Jeremy erstellt
create database if not exists genericdb;
use genericdb;

-- Klasse einfügen
INSERT INTO `tobjectclass`(`TObjectClassID`,`Bezeichnung`)
VALUES (1, 'HD');

-- Eigenschaften einfügen
INSERT INTO `tproperty`(`TPropertyID`,`Name`,`MussFeld`,`Beschreibung`,`TObjectClassID`,`TDataTypesID`)
VALUES
(1,'Drehzahl',1,'Drehzahl der HD',1,1),
(2,'Speicherkapazität',1,'Speicherkapazität in [GB]',1,2),
(3,'Grösse in Zoll',1,'Grösse der HD [Zoll]',1,3),
(4,'Typ',1,'Type der HD',1,4);

-- Objekt erfassen
INSERT INTO `tobject`(`TObjectID`,`Beschreibung`,`TObjectClassID`)
VALUES
(10, 'IBM HD',1);


INSERT INTO `tvalue`
(`TValueID`,`Value`,`TObjectID`,`TPropertyID`)
VALUES
(1,'7200',10,1),
(2, '500', 10, 2),
(3, '2.5', 10, 3),
(4, 'SSD', 10, 4);

INSERT INTO `tdataType`(`tdatatypeid`,`DataType`, `Beschreibung`)
VALUES
(1,"Varchar", "Text"),
(2,"Int", "Ganzzahl"),
(3,"Float", "Kommazahl");

select tproperty.Name,
	   tvalue.Value from tobject inner join tobjectclass
				on tobject.TObjectClassID = tobjectclass.TObjectClassID
			inner join tproperty
				on tproperty.TObjectClassID = tobjectclass.TObjectClassID
			inner join tvalue
				on tvalue.TObjectID = tobject.TObjectID
					and tvalue.tpropertyID = tproperty.TPropertyID
	  where tobject.TObjectID = 10;





