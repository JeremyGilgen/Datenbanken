-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema GenericDB
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema GenericDB
-- -----------------------------------------------------
drop schema if exists genericdb;
CREATE SCHEMA IF NOT EXISTS `GenericDB` DEFAULT CHARACTER SET utf8 ;
USE `GenericDB` ;

-- -----------------------------------------------------
-- Table `GenericDB`.`TObjectClass`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GenericDB`.`TObjectClass` (
  `TObjectClassID` INT NOT NULL,
  `Bezeichnung` VARCHAR(60) NULL,
  PRIMARY KEY (`TObjectClassID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `GenericDB`.`TObject`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GenericDB`.`TObject` (
  `TObjectID` INT NOT NULL,
  `Beschreibung` VARCHAR(60) NULL,
  `TObjectClassID` INT NOT NULL,
  PRIMARY KEY (`TObjectID`),
  INDEX `TObject_TObjectClass1_idx` (`TObjectClassID` ASC),
  CONSTRAINT `TObject_TObjectClass1`
    FOREIGN KEY (`TObjectClassID`)
    REFERENCES `GenericDB`.`TObjectClass` (`TObjectClassID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `GenericDB`.`TDataType`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GenericDB`.`TDataType` (
  `TDataTypeID` INT NOT NULL,
  `DataType` VARCHAR(60) NULL,
  `Beschreibung` VARCHAR(60) NULL,
  PRIMARY KEY (`TDataTypeID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `GenericDB`.`TProperty`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GenericDB`.`TProperty` (
  `TPropertyID` INT NOT NULL,
  `Name` VARCHAR(60) NULL,
  `MussFeld` TINYINT(1) NULL,
  `Beschreibung` VARCHAR(200) NULL,
  `TObjectClassID` INT NOT NULL,
  `TDataTypesID` INT NOT NULL,
  PRIMARY KEY (`TPropertyID`),
  INDEX `TProperty_TObjectClass_idx` (`TObjectClassID` ASC),
  INDEX `TProperty_TDataTypes1_idx` (`TDataTypesID` ASC),
  CONSTRAINT `TProperty_TObjectClass`
    FOREIGN KEY (`TObjectClassID`)
    REFERENCES `GenericDB`.`TObjectClass` (`TObjectClassID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `TProperty_TDataTypes1`
    FOREIGN KEY (`TDataTypesID`)
    REFERENCES `GenericDB`.`TDataType` (`TDataTypeID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `GenericDB`.`TValue`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GenericDB`.`TValue` (
  `TValueID` INT NOT NULL AUTO_INCREMENT,
  `Value` VARCHAR(60) NULL,
  `TObjectID` INT NOT NULL,
  `TPropertyID` INT NOT NULL,
  PRIMARY KEY (`TValueID`),
  INDEX `TValues_TObject1_idx` (`TObjectID` ASC),
  INDEX `TValues_TProperty1_idx` (`TPropertyID` ASC),
  CONSTRAINT `TValues_TObject1`
    FOREIGN KEY (`TObjectID`)
    REFERENCES `GenericDB`.`TObject` (`TObjectID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `TValues_TProperty1`
    FOREIGN KEY (`TPropertyID`)
    REFERENCES `GenericDB`.`TProperty` (`TPropertyID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
