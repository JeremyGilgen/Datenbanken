create TABLE if not exists Bewertung (							
		Bewertung_ID	INT(11) not null AUTO_INCREMENT primary key,
		Bewertung		double(3,2),
		Note			double(3,2)
    );
    
create TABLE if not exists Musikalbum (							
		Musikalbum_ID	INT(11) not null AUTO_INCREMENT primary key,
		Titel			varchar(50),
		Stil			varchar(50),
        Interpreter		varchar(50),
        Bewertung_ID	INT(11),
        FOREIGN KEY(Bewertung_ID)
        REFERENCES musikstück.Bewertung(Bewertung_ID)
    );
    
create TABLE if not exists Musikstück (							
		Musikstück_ID	INT(11) not null AUTO_INCREMENT primary key,
		Musikstück		varchar(50),
		Dauer			Float(4)
    );
    
create TABLE if not exists Träger (							
		Träger_ID	INT(11) not null AUTO_INCREMENT primary key,
		Träger		varchar(50),
		Ort			varchar(50)
    );
    
create TABLE if not exists Musikalbum_Träger (							
		Musikalbum_ID	INT(11) not null,
		Träger_ID		INT(11) not null,
        Primary Key(Musikalbum_ID, Träger_ID),
        FOREIGN KEY(Musikalbum_ID)
        REFERENCES musikstück.Musikalbum(Musikalbum_ID),
        FOREIGN KEY(Träger_ID)
        REFERENCES musikstück.Träger(Träger_ID)
    );
    
create TABLE if not exists Interpreter (							
		Interpreter_ID	INT(11) not null AUTO_INCREMENT primary key,
		Interpreter		varchar(50)
    );

create TABLE if not exists Musikalbum_Interpreter (							
		Musikalbum_ID	INT(11) not null,
		Interpreter_ID		INT(11) not null,
        Primary Key(Musikalbum_ID, Interpreter_ID),
        FOREIGN KEY(Musikalbum_ID)
        REFERENCES musikstück.Musikalbum(Musikalbum_ID),
        FOREIGN KEY(Interpreter_ID)
        REFERENCES musikstück.Interpreter(Interpreter_ID)
    );
    
create TABLE if not exists Musikalbum_Musikstück (							
		Musikstück_ID	INT(11) not null,
		Musikalbum_ID	INT(11) not null,
        PRIMARY KEY(Musikstück_ID, Musikalbum_ID),
        FOREIGN KEY(Musikstück_ID)
        REFERENCES musikstück.Musikstück(Musikstück_ID),
        FOREIGN KEY(Musikalbum_ID)
        REFERENCES musikstück.Musikalbum(Musikalbum_ID)
    );
    
insert into Bewertung (Bewertung, Note)
values (5,5 ),
	   (5.5,1 ),
       (1,1 ),
	   (1,1 ),
	   (1,1 );
